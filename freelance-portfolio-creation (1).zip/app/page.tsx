"use client"

import { useState } from "react"
import { Menu, X, Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Portfolio() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const projects = [
    {
      title: "Real Estate Credit Management System",
      company: "Wafa Immobilier",
      period: "Feb - Jul 2025",
      description:
        "Enterprise banking application for mortgage credit management. Built secure REST APIs with OAuth2/JWT authentication and comprehensive transaction tracking.",
      technologies: ["Spring Boot", "Angular", "Oracle DB", "JWT/OAuth2", "GitLab CI/CD", "Wildfly"],
      impact: "Handles 1000+ daily transactions with zero downtime",
      role: "Full Stack Engineer",
    },
    {
      title: "Legal Cabinet Management Suite",
      company: "SmartProg SARL",
      period: "Jul - Aug 2024",
      description:
        "Complete SaaS platform for legal firms to manage cases, clients, and documents. Implemented secure JWT authentication and intuitive case management workflows.",
      technologies: ["Spring Boot", "Angular", "JWT Auth", "MySQL", "RESTful APIs"],
      impact: "Successfully onboarded 15+ legal firms",
      role: "Full Stack Developer",
    },
    {
      title: "Commercial Management Platform",
      company: "SmartProg SARL",
      period: "Jul - Aug 2023",
      description:
        "Complete business operations platform featuring inventory management, sales tracking, and client relationship management with real-time analytics.",
      technologies: ["Spring Boot", "Angular", "MySQL", "REST APIs", "Data Analytics"],
      impact: "Streamlined operations for SMEs, reducing manual work by 70%",
      role: "Full Stack Developer",
    },
  ]

  const skills = {
    Backend: ["Java/Spring Boot", "Hibernate ORM", "REST APIs", "Microservices", "OAuth2/JWT", "MySQL & Oracle"],
    Frontend: ["Angular", "Angular Native", "Responsive Design", "State Management", "RxJS"],
    "DevOps & Cloud": ["Docker", "GitLab CI/CD", "Wildfly", "NGINX", "Oracle Cloud"],
    Methodologies: ["Agile/Scrum", "Clean Architecture", "SOLID Principles", "UML Design"],
  }

  const languages = [
    { name: "French", level: "Professional" },
    { name: "English", level: "Professional" },
    { name: "Arabic", level: "Native" },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-lg border-b border-border/50 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-16">
          <div className="text-2xl font-bold gradient-text">AJ.</div>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8">
            <a href="#about" className="text-muted-foreground hover:text-foreground transition">
              About
            </a>
            <a href="#projects" className="text-muted-foreground hover:text-foreground transition">
              Projects
            </a>
            <a href="#skills" className="text-muted-foreground hover:text-foreground transition">
              Skills
            </a>
            <a href="#contact" className="text-muted-foreground hover:text-foreground transition">
              Contact
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-card border-t border-border/50 p-4 space-y-4">
            <a
              href="#about"
              className="block text-muted-foreground hover:text-foreground transition"
              onClick={() => setMobileMenuOpen(false)}
            >
              About
            </a>
            <a
              href="#projects"
              className="block text-muted-foreground hover:text-foreground transition"
              onClick={() => setMobileMenuOpen(false)}
            >
              Projects
            </a>
            <a
              href="#skills"
              className="block text-muted-foreground hover:text-foreground transition"
              onClick={() => setMobileMenuOpen(false)}
            >
              Skills
            </a>
            <a
              href="#contact"
              className="block text-muted-foreground hover:text-foreground transition"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </a>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-6 mb-12">
            <h1 className="text-5xl md:text-7xl font-bold leading-tight">
              Crafting <span className="gradient-text">Enterprise-Grade</span> Solutions
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl leading-relaxed">
              Full Stack Developer specializing in scalable Java/Spring Boot backends and dynamic Angular frontends.
              Ready for your next project on Upwork.
            </p>
          </div>

          <div className="flex flex-wrap gap-4">
            <a href="#projects" className="inline-block">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                View My Work
              </Button>
            </a>
            <a href="#contact" className="inline-block">
              <Button
                size="lg"
                variant="outline"
                className="border-primary/50 text-primary hover:bg-primary/10 bg-transparent"
              >
                Hire Me Now
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 section-divider">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold mb-8">About Me</h2>
          <div className="space-y-4 text-muted-foreground text-lg leading-relaxed">
            <p>
              I'm an <span className="text-foreground font-semibold">Engineering Graduate in Information Systems</span>{" "}
              with proven expertise in designing and implementing complete full-stack applications. My background
              combines enterprise-level development experience with a passion for clean architecture and secure coding
              practices.
            </p>
            <p>
              My specialization lies in building <span className="text-foreground font-semibold">robust REST APIs</span>{" "}
              with OAuth2/JWT authentication, developing responsive Angular frontends, and architecting microservices
              that scale. I've worked on real-world banking and legal tech applications, ensuring zero downtime and
              maximum security.
            </p>
            <p>
              I'm <span className="text-foreground font-semibold">methodical and results-oriented</span>, following
              Agile/Scrum practices and maintaining clear communication with stakeholders. Based in Casablanca, I'm
              available for immediate freelance engagement on Upwork and similar platforms.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 section-divider">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold mb-12">Featured Projects</h2>

          <div className="space-y-8">
            {projects.map((project, idx) => (
              <div
                key={idx}
                className="bg-card border border-border/50 rounded-lg p-8 hover:border-primary/50 transition"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold mb-1">{project.title}</h3>
                    <p className="text-primary font-semibold">{project.company}</p>
                  </div>
                  <span className="text-muted-foreground text-sm">{project.period}</span>
                </div>

                <p className="text-muted-foreground mb-4 leading-relaxed">{project.description}</p>

                <div className="mb-4">
                  <p className="text-accent font-semibold mb-2">✓ {project.impact}</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech, tidx) => (
                    <span key={tidx} className="px-3 py-1 bg-muted text-foreground rounded-full text-sm font-medium">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8 section-divider">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold mb-12">Technical Skills</h2>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {Object.entries(skills).map(([category, skillList], idx) => (
              <div key={idx} className="bg-card border border-border/50 rounded-lg p-6">
                <h3 className="text-lg font-bold mb-4 text-primary">{category}</h3>
                <ul className="space-y-2">
                  {skillList.map((skill, sidx) => (
                    <li key={sidx} className="text-muted-foreground flex items-center">
                      <span className="w-2 h-2 bg-accent rounded-full mr-3"></span>
                      {skill}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Languages */}
          <div className="bg-card border border-border/50 rounded-lg p-6">
            <h3 className="text-lg font-bold mb-4 text-primary">Languages</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {languages.map((lang, idx) => (
                <div key={idx}>
                  <p className="font-semibold mb-1">{lang.name}</p>
                  <p className="text-muted-foreground text-sm">{lang.level}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 section-divider">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Let's Work Together</h2>
          <p className="text-xl text-muted-foreground mb-12 leading-relaxed">
            I'm actively looking for freelance projects on Upwork and Marketplace. Whether you need a complete
            application, API development, or technical consultation, let's connect.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <a href="mailto:achrafjarrou2002@gmail.com">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Mail className="mr-2" size={20} />
                Email Me
              </Button>
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="border-primary/50 text-primary hover:bg-primary/10 bg-transparent"
              >
                <Linkedin className="mr-2" size={20} />
                LinkedIn
              </Button>
            </a>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="border-primary/50 text-primary hover:bg-primary/10 bg-transparent"
              >
                <Github className="mr-2" size={20} />
                GitHub
              </Button>
            </a>
          </div>

          <div className="bg-card border border-border/50 rounded-lg p-8">
            <p className="text-muted-foreground mb-2">📍 Based in Casablanca, Morocco</p>
            <p className="text-muted-foreground mb-2">📱 +212 (0)6 97 83 80 50</p>
            <p className="text-muted-foreground">✉️ achrafjarrou2002@gmail.com</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground text-sm">
          <p>© 2025 Achraf Jarrou. Available for freelance projects on Upwork and Marketplace.</p>
        </div>
      </footer>
    </div>
  )
}
